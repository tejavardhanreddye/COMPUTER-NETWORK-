"""Task 5: Handover and LoRaWAN capacity calculations."""

route_m = 1_200
agv_speed_mps = 2
wifi_ap_spacing_m = 30
wifi_handover_s = 0.150
five_g_cell_m = 300
five_g_handover_s = 0.020

sensor_count = 600
sensor_bytes_per_second = 50
lorawan_capacity_bps = 5_000

trip_time_s = route_m / agv_speed_mps
wifi_handovers = route_m // wifi_ap_spacing_m
five_g_handovers = route_m // five_g_cell_m

wifi_unreachable_s = wifi_handovers * wifi_handover_s
five_g_unreachable_s = five_g_handovers * five_g_handover_s

sensor_rate_bps = sensor_count * sensor_bytes_per_second * 8

print("TASK 5 – WIRELESS CALCULATIONS")
print(f"Travel time: {trip_time_s:.1f} seconds")
print(f"Wi-Fi handovers (approx.): {wifi_handovers:.0f}")
print(f"Wi-Fi unreachable time: {wifi_unreachable_s:.2f} seconds")
print(f"5G handovers (approx.): {five_g_handovers:.0f}")
print(f"5G unreachable time: {five_g_unreachable_s:.2f} seconds")
print(f"600 sensors aggregate rate: {sensor_rate_bps} bps")
print(f"LoRaWAN capacity assumed: {lorawan_capacity_bps} bps")
print(f"Fits in assumed capacity: {sensor_rate_bps <= lorawan_capacity_bps}")
print("\nNote: Handover counts depend on route endpoints and cell/AP layout; state your assumption in the report.")
