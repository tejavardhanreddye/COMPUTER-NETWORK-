"""Task 9: Stop-and-wait and sliding-window link utilisation."""

def utilisation(frame_bits, rate_bps, distance_m, window, speed=2e8):
    if frame_bits <= 0 or rate_bps <= 0 or distance_m < 0 or window <= 0 or speed <= 0:
        raise ValueError("Inputs must be positive (distance may be zero).")
    tx = frame_bits / rate_bps
    prop = distance_m / speed
    a = prop / tx
    u = min(1.0, window / (1 + 2 * a))
    return u, a

links = [
    ("Campus LAN, 200 m, 1 Gbps", 1e9, 200),
    ("City fibre, 50 km, 1 Gbps", 1e9, 50_000),
    ("Satellite, 36,000 km, 10 Mbps", 10e6, 36_000_000),
]

if __name__ == "__main__":
    for name, rate, distance in links:
        u1, a = utilisation(12_000, rate, distance, 1)
        u7, _ = utilisation(12_000, rate, distance, 7)
        u127, _ = utilisation(12_000, rate, distance, 127)
        print(f"{name:<31} a = {a:7.2f} stop-and-wait {u1:6.1%} "
              f"W=7 {u7:6.1%} W=127 {u127:6.1%}")

    # Assignment head-office link: 400 km fibre, 1 Gbps, 1500-byte frame.
    u, a = utilisation(1500 * 8, 1e9, 400_000, 1)
    tx = (1500 * 8) / 1e9
    prop = 400_000 / 2e8
    min_window = int((1 + 2 * a) + 0.999999999)
    print("\nHead-office link")
    print(f"Transmission time: {tx * 1000:.3f} ms")
    print(f"One-way propagation: {prop * 1000:.3f} ms")
    print(f"a = {a:.2f}")
    print(f"Stop-and-wait utilisation: {u:.2%}")
    print(f"Smallest full-utilisation window (ceiling): {min_window}")
