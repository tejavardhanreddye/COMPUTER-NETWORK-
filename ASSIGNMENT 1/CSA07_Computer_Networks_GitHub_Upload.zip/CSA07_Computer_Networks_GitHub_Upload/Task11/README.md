# Task 11 – Defend the Network Design

Write your final recommendation using numerical results from Tasks 1–10.

Include:
- Medium, wireless technology and Ethernet settings for each area.
- Error-control and flow-control method for each link, with calculations.
- Two biggest remaining risks.
- Whether the design scales to five plants.
- Alternative analysis: private 5G throughout the plant versus wired backbone plus Wi-Fi.
