"""Task 3: Encapsulation and decapsulation across four layers."""

LAYERS = [
    ("Application", "HTTP"),
    ("Transport", "TCP"),
    ("Network", "IP"),
    ("Data link", "ETH"),
]

def send(message):
    pdu = message
    for layer, tag in LAYERS:
        if tag == "ETH":
            pdu = f"[{tag}|{pdu}|FCS]"
        else:
            pdu = f"[{tag}|{pdu}]"
        print(f"{layer} adds {tag:<3} -> {len(pdu)} bytes")
    return pdu

def receive(frame):
    pdu = frame
    for layer, tag in reversed(LAYERS):
        head = "[" + tag + "|"
        tail = "|FCS]" if tag == "ETH" else "]"
        if not (pdu.startswith(head) and pdu.endswith(tail)):
            raise ValueError(f"{layer}: bad header or trailer")
        pdu = pdu[len(head):-len(tail)]
    return pdu

if __name__ == "__main__":
    message = "GET /results"
    frame = send(message)
    print("on the wire:", frame)
    print("delivered :", receive(frame))
    print(f"overhead   : {len(frame) - len(message)} bytes for {len(message)} bytes of data")
