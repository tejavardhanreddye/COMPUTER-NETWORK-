# Task 2 – Collision and Broadcast Domains

Add:
- Your marked topology diagram.
- Collision-domain and broadcast-domain counts.
- Device OSI-layer explanation.
- Point-to-point / multipoint connection notes.
- Standards table.
- Comparison after replacing hubs with switches.

Required practical file: `office.pkt` (create and save this in Cisco Packet Tracer).
Required evidence: screenshots of your own Packet Tracer topology.

Do not use a blank or sample file as evidence.
