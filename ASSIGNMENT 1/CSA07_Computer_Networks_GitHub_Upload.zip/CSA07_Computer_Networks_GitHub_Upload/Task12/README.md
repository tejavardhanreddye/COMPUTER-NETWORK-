# Task 12 – Day-4 Design Challenge

The assignment adds a private 5G network and 50 AGVs.

Include:
- Impact analysis and recalculated traffic with AGVs.
- Test of the original design using handover and delay calculations.
- Your adapted or redesigned network.
- Evidence-based defence with numbers and trade-offs.

Required Packet Tracer evidence:
- Save your revised simulation as `revised.pkt`.
- Add screenshots of your own revised topology and relevant configurations.
