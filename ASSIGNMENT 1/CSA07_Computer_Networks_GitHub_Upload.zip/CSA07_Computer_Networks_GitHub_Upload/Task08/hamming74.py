"""Task 8: Hamming(7,4) single-bit error correction."""

def encode(data):
    if len(data) != 4 or any(bit not in (0, 1) for bit in data):
        raise ValueError("Input must contain exactly four bits (0 or 1).")
    p1 = data[0] ^ data[1] ^ data[3]
    p2 = data[0] ^ data[2] ^ data[3]
    p3 = data[1] ^ data[2] ^ data[3]
    return [p1, p2, data[0], p3, data[1], data[2], data[3]]

def decode(codeword):
    if len(codeword) != 7 or any(bit not in (0, 1) for bit in codeword):
        raise ValueError("Codeword must contain exactly seven bits (0 or 1).")
    s1 = codeword[0] ^ codeword[2] ^ codeword[4] ^ codeword[6]
    s2 = codeword[1] ^ codeword[2] ^ codeword[5] ^ codeword[6]
    s3 = codeword[3] ^ codeword[4] ^ codeword[5] ^ codeword[6]
    pos = s1 + 2 * s2 + 4 * s3
    corrected = codeword[:]
    if pos:
        corrected[pos - 1] ^= 1
    data = [corrected[2], corrected[4], corrected[5], corrected[6]]
    return pos, data

if __name__ == "__main__":
    word = encode([1, 0, 1, 1])
    print("codeword      :", "".join(map(str, word)))
    for flip in (None, 5):
        received = word[:]
        if flip:
            received[flip - 1] ^= 1
        pos, data = decode(received)
        print(f"error at {str(flip):<4}: syndrome {pos}, data {''.join(map(str, data))}")
