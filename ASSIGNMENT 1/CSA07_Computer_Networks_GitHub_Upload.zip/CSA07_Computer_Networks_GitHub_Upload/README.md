# CSA07 – Computer Networks | Assignment 1 (CO1)

**Assignment:** Make the Data of a Smart Manufacturing Plant Arrive Correctly and On Time

## Student details
- Student name: YOUR NAME
- Register number: YOUR REGISTER NUMBER
- Department / Section: YOUR DEPARTMENT AND SECTION
- Operating system: YOUR OS
- Python version: Run `python --version`
- Cisco Packet Tracer / NS-3 version: ENTER VERSION USED

## Repository contents
There is one folder for each task (Task01 to Task12). Add your own practical evidence to the matching folder.

| Folder | Task |
|---|---|
| Task01 | Traffic sizing |
| Task02 | Collision and broadcast domains, standards |
| Task03 | Reading a frame layer by layer |
| Task04 | Transmission media |
| Task05 | Wi-Fi 6 or 5G for moving equipment |
| Task06 | Ethernet port report |
| Task07 | CRC, parity and checksum |
| Task08 | Hamming code and FEC vs ARQ |
| Task09 | Sliding window and ARQ |
| Task10 | Delay analysis, ping, traceroute and Wireshark |
| Task11 | Final network recommendation |
| Task12 | Day-4 design challenge |

## Running the Python programs
Install Python 3. Open a terminal in the repository folder and run the required program. Example:

```bash
python Task03/frame_encapsulation.py
python Task04/nyquist_shannon.py
python Task07/crc.py
python Task08/hamming74.py
python Task09/window_utilisation.py
```

Other calculation scripts are in Task01 and Task05.

## Evidence you must add yourself
- **Task02:** `office.pkt` and screenshots of your Packet Tracer topology.
- **Task03:** Your own Wireshark `.pcapng` capture and labelled screenshot.
- **Task06:** Actual `ethtool` output before and after the duplex correction (or equivalent Windows evidence).
- **Task10:** Your own ping and traceroute outputs, measurement table, Wireshark capture and labelled screenshots.
- **Task12:** Your revised Packet Tracer file named `revised.pkt` and screenshots.
- For all tasks: add your calculations, diagrams, outputs and interpretation as required by the assignment.

Do not submit empty placeholders as evidence. Replace each `ADD_YOUR_EVIDENCE_HERE.txt` with your actual files or remove the placeholder after adding the evidence.

## Commit history
The assignment asks for progressive work and at least one commit for each task. Commit each task folder as you complete it. Do not upload everything in one final commit.

## Important
This repository is a starter pack. You must run and understand the programs, check the results, complete the written calculations and add your own practical evidence. The separate assignment report is also required.
