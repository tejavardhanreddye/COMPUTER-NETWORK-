"""Task 7: CRC error detection using modulo-2 division."""

def mod2_div(dividend, divisor):
    """Return the modulo-2 division remainder."""
    if not dividend or not divisor or set(dividend + divisor) - {"0", "1"}:
        raise ValueError("Dividend and divisor must be non-empty bit strings.")
    if divisor[0] != "1":
        raise ValueError("Divisor must begin with 1.")
    rem = list(dividend)
    for i in range(len(dividend) - len(divisor) + 1):
        if rem[i] == "1":
            for j in range(len(divisor)):
                rem[i + j] = "0" if rem[i + j] == divisor[j] else "1"
    return "".join(rem[-(len(divisor) - 1):]) if len(divisor) > 1 else ""

def encode(data, gen):
    crc = mod2_div(data + "0" * (len(gen) - 1), gen)
    return data + crc

def check(frame, gen):
    remainder = mod2_div(frame, gen)
    return set(remainder) <= {"0"}

if __name__ == "__main__":
    gen = "1011"
    frame = encode("1101011011", gen)
    print("transmitted:", frame)
    print("no error   :", check(frame, gen))
    bad = frame[:4] + ("1" if frame[4] == "0" else "0") + frame[5:]
    print("1-bit error:", check(bad, gen))
    burst = frame[:2] + "".join("1" if b == "0" else "0" for b in frame[2:5]) + frame[5:]
    print("3-bit burst:", check(burst, gen))
